This is the README file for A0103516U's submission

== General Notes about this assignment ==

Hi Min, my code quality is bad, but i just tried to make it work first.
I used a threshold to determine of the string is alien, and ive put my threshold as 50%, since if there are more ngrams that arent recognised than there are, it is highly likely that the sentence doesnt belong to a particular language.
I have tried to name variables to signify their purpose and added comments to explain further
Sorry for the trouble!

== Files included with this submission ==

README.txt			: This document!!!
build_test_LM.py	: The main file for building a LM and using it to test a set of inputs
ESSAY.txt			: The answers to the questions asked in the homework

== Statement of individual work ==

Please initial one of the following statements.

[x] I, A0103516U, certify that I have followed the CS 3245 Information
Retrieval class guidelines for homework assignments.  In particular, I
expressly vow that I have followed the Facebook rule in discussing
with others in doing the assignment and did not take notes (digital or
printed) from the discussions.  

[ ] I, A0103516U, did not follow the class rules regarding homework
assignment, because of the following reason:

<Please fill in>

I suggest that I should be graded as follows:

I tried to just look at the homework page on the website and follow my instincts to make this work

== References ==

 - Talked to Varun Patro to discuss how the alien sentences should be handled
 - Lots of stackoverflow to solve problems
